extern const int BlueCoin; //0x080014F0
extern const int GoldCoin; //0x08002860
extern const int N64Coin; //0x080037B8
extern const int RedCoin; //0x08004B20
extern const int BattleFlag; //0x08005DF8
extern const int BlueFlag; //0x080070C8
extern const int BowserFlag; //0x08008398
extern const int DKFlag; //0x08009668
extern const int LuigiFlag; //0x0800A938
extern const int MarioFlag; //0x0800BC08
extern const int PeachFlag; //0x0800CED8
extern const int BattleFlag; //0x0800E1A8
extern const int ToadFlag; //0x0800F478
extern const int WarioFlag; //0x08010748
extern const int YoshiFlag; //0x08011A18
extern const int BowserMushroom; //0x080130C0
extern const int DKMushroom; //0x08014770
extern const int LuigiMushroom; //0x08015E20
extern const int MarioMushroom; //0x080174D0
extern const int PeachMushroom; //0x08018B80
extern const int RedMushroom; //0x0801A230
extern const int ToadMushroom; //0x0801B8E0
extern const int WarioMushroom; //0x0801CF90
extern const int YoshiMushroom; //0x0801E640
extern const int TargetMarker; //0x0801F010
extern const int SoccerBall; //0x080200C0
#define ModelData_RawDataSize 0x1FF38
#define ModelData_CompressedSize 0xA21C
