extern const int BlueCoin; //0x080014E0
extern const int GoldCoin; //0x08002840
extern const int N64Coin; //0x08003788
extern const int RedCoin; //0x08004AE0
extern const int BattleFlag; //0x08005DA8
extern const int BlueFlag; //0x08007068
extern const int BowserFlag; //0x08008328
extern const int DKFlag; //0x080095E8
extern const int LuigiFlag; //0x0800A8A8
extern const int MarioFlag; //0x0800BB68
extern const int PeachFlag; //0x0800CE28
extern const int BattleFlag; //0x0800E0E8
extern const int ToadFlag; //0x0800F3A8
extern const int WarioFlag; //0x08010668
extern const int YoshiFlag; //0x08011928
extern const int BowserMushroom; //0x08012FC0
extern const int DKMushroom; //0x08014660
extern const int LuigiMushroom; //0x08015D00
extern const int MarioMushroom; //0x080173A0
extern const int PeachMushroom; //0x08018A40
extern const int RedMushroom; //0x0801A0E0
extern const int ToadMushroom; //0x0801B780
extern const int WarioMushroom; //0x0801CE20
extern const int YoshiMushroom; //0x0801E4C0
extern const int PointMarker; //0x0801F630
extern const int SoccerBall; //0x080206D0
#define ModelData_RawDataSize 0x20548
#define ModelData_CompressedSize 0xADF0
